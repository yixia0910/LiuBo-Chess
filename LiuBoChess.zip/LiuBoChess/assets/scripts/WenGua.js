
cc.Class({
    extends: cc.Component,

    properties: {
      
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {

    },

    wengua() {
        let number = Math.floor(Math.random() * 8) + 1;
        return
    },
    // update (dt) {},
});
