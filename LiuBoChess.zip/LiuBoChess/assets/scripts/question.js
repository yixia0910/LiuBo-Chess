var questions = [];
questions[1] = "1";
questions[2] = "2";
questions[3] = "3";
questions[4] = "4";
questions[5] = "5";
questions[6] = "6";
questions[7] = "7";
questions[8] = "8";
questions[9] = "9";
cc.Class({
    extends: cc.Component,

    properties: {
        Label: cc.Label,
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {

    },

    setLabel(number){
        this.Label.string = questions[number];
    },
    // update (dt) {},
});
