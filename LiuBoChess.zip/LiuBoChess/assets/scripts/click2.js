
cc.Class({
    extends: cc.Component,

    properties: {

    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {

    },

    toOver: function () {
        cc.director.loadScene("over");
    },
    // update (dt) {},
});
