
cc.Class({
    extends: cc.Component,

    properties: {

    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {

    },
    
    toGuaxiang: function () {
        cc.director.loadScene("guaxiang");
    },
});
