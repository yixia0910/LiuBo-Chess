"use strict";
cc._RF.push(module, 'a34fb6Mt2lGN7g1ROvP3TR+', 'WenGua');
// scripts/WenGua.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {},
    wengua: function wengua() {
        var number = Math.floor(Math.random() * 8) + 1;
        return;
    }
}
// update (dt) {},
);

cc._RF.pop();