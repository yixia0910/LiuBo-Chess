"use strict";
cc._RF.push(module, '6a3ccayfy9BP4lG+BsI2sx7', 'click4');
// scripts/click4.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {},


    toIntro: function toIntro() {
        cc.director.loadScene("intro");
    }
});

cc._RF.pop();