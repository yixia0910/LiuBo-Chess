"use strict";
cc._RF.push(module, 'e5300wgXL9FtouFDC0JdioQ', 'click3');
// scripts/click3.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {},


    toStart: function toStart() {
        cc.director.loadScene("start");
    }
});

cc._RF.pop();