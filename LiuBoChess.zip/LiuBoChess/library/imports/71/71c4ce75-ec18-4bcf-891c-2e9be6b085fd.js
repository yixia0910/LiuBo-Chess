"use strict";
cc._RF.push(module, '71c4c517BhLz4kcLpvmsIX9', 'click6');
// scripts/click6.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {},


    toGuaxiang: function toGuaxiang() {
        cc.director.loadScene("guaxiang");
    }
});

cc._RF.pop();