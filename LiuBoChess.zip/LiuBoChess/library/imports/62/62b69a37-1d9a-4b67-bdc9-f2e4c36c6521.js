"use strict";
cc._RF.push(module, '62b69o3HZpLZ73J8uTDbGUh', 'click5');
// scripts/click5.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {},


    toQipan: function toQipan() {
        cc.director.loadScene("qipan");
    }
});

cc._RF.pop();