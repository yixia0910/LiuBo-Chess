"use strict";
cc._RF.push(module, '9fa75haopNMxpJ6Nzy+0d1e', 'click1');
// scripts/click1.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {},


    toGame: function toGame() {
        cc.director.loadScene("game");
    }
});

cc._RF.pop();