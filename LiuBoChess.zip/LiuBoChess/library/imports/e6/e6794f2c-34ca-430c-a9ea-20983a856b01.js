"use strict";
cc._RF.push(module, 'e67948sNMpDDKnqIJg6hWsB', 'game');
// scripts/game.js

"use strict";

var MOVE_DURATION = 0.1;
var blockLocation = [];
var lockLocation = [];
blockLocation[1] = {
    x: 5,
    y: -597
};
blockLocation[2] = {
    x: -316,
    y: -291
};
blockLocation[3] = {
    x: -6,
    y: 33
};
blockLocation[4] = {
    x: 316,
    y: -271
};
blockLocation[5] = {
    x: 93,
    y: -445
};
blockLocation[6] = {
    x: -93,
    y: -445
};
blockLocation[7] = {
    x: -156,
    y: -380
};
blockLocation[8] = {
    x: -158,
    y: -186
};
blockLocation[9] = {
    x: -93,
    y: -119
};
blockLocation[10] = {
    x: 93,
    y: -119
};
blockLocation[11] = {
    x: 158,
    y: -186
};
blockLocation[12] = {
    x: 158,
    y: -380
};
lockLocation[1] = {
    x: -186,
    y: -467
};
lockLocation[2] = {
    x: -186,
    y: -96
};
lockLocation[3] = {
    x: 183.8,
    y: -95.9
};
lockLocation[4] = {
    x: 183.8,
    y: -467
};
cc.Class({
    extends: cc.Component,

    properties: {
        kun: {
            default: null,
            type: cc.Sprite
        },
        qian: {
            default: null,
            type: cc.Sprite
        },
        xun: {
            default: null,
            type: cc.Sprite
        },
        li: {
            default: null,
            type: cc.Sprite
        },
        dui: {
            default: null,
            type: cc.Sprite
        },
        zhen: {
            default: null,
            type: cc.Sprite
        },
        kan: {
            default: null,
            type: cc.Sprite
        },
        gen: {
            default: null,
            type: cc.Sprite
        },
        bg: cc.Node,
        blockPrefab: cc.Prefab,
        lockPrefab: cc.Prefab,
        StepLabel: cc.Label,
        step: 0
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},


    start: function start() {
        this.init();
        this.init2();
    },
    init: function init() {
        this.qian.node.active = false;
        this.kun.node.active = false;
        this.zhen.node.active = false;
        this.xun.node.active = false;
        this.kan.node.active = false;
        this.li.node.active = false;
        this.gen.node.active = false;
        this.dui.node.active = false;
        cc.log("init");
    },
    init2: function init2() {
        cc.log("init2");
        this.blockSize = 70;
        this.lockSize = 40;
        this.blocks = [];
        this.locks = [];
        for (var i = 1; i <= 12; ++i) {
            var block = cc.instantiate(this.blockPrefab);
            block.width = this.blockSize;
            block.height = this.blockSize;
            this.bg.addChild(block);
            block.setPosition(cc.v2(blockLocation[i].x, blockLocation[i].y));
            block.getComponent('block').setLabel(0);
            this.blocks[i] = null;
        }
        for (var _i = 1; _i <= 4; ++_i) {
            var lock = cc.instantiate(this.lockPrefab);
            lock.width = this.lockSize;
            lock.height = this.lockSize;
            this.bg.addChild(lock);
            lock.setPosition(cc.v2(lockLocation[_i].x, lockLocation[_i].y));
            lock.getComponent('lock').setLabel(0);
            this.locks[_i] = lock;
        }
        //this.first();
        this.location = 1;
        this.level = 1;
        this.isOut = 1;
        this.lock = 0;
        this.move = 0;
    },
    first: function first() {
        var block = cc.instantiate(this.blockPrefab);
        block.width = this.blockSize;
        block.height = this.blockSize;
        this.bg.addChild(block);
        block.setPosition(cc.v2(blockLocation[1].x, blockLocation[1].y));
        block.getComponent('block').setLabel(1);
        this.blocks[1] = block;
        this.step = 0;
        cc.log("first");
    },
    updateStep: function updateStep(number) {
        this.step = number;
        this.StepLabel.string = "步数:" + this.step;
    },


    wenGua: function wenGua() {
        this.init();
        var number = Math.floor(Math.random() * 8) + 1;
        if (number == 1) {
            this.qian.node.active = true;
        } else if (number == 2) {
            this.kun.node.active = true;
        } else if (number == 3) {
            this.zhen.node.active = true;
        } else if (number == 4) {
            this.xun.node.active = true;
        } else if (number == 5) {
            this.kan.node.active = true;
        } else if (number == 6) {
            this.li.node.active = true;
        } else if (number == 7) {
            this.gen.node.active = true;
        } else if (number == 8) {
            this.dui.node.active = true;
        }
        this.toMove(number);
    },

    toMove: function toMove(number) {
        if (this.move == 0) {
            this.first();
            this.move = 1;
            return;
        }
        this.updateStep(this.step + 1);
        cc.log(number);
        if (number == 1) {
            //san to xiao
            if (this.lock != 0) return;
            if (this.level == 1) {
                this.blocks[this.location].getComponent('block').setLabel(2);
                this.level = 2;
            } else {
                this.toMove(3);
                this.step--;
            }
        } else if (number == 2) {
            //xiao to san
            if (this.lock != 0) return;
            if (this.level == 2) {
                this.blocks[this.location].getComponent('block').setLabel(1);
                this.level = 1;
            } else {
                this.toMove(4);
                this.step--;
            }
        } else if (number == 3) {
            //forward one step
            var block = this.blocks[this.location];
            if (this.lock != 0) return;
            this.blocks[this.location] = null;
            if (this.level == 1) {
                if (this.isOut == 1) {
                    this.location = (this.location + 1) % 4;
                    if (this.location == 0) this.location = 4;
                } else {
                    if (this.location == 12) {
                        this.location = 1;
                        this.isOut = 1;
                    }
                }
            } else {
                this.location += 1;
                if (this.location == 5) this.isOut = 0;else if (this.location == 13) this.location = 5;
            }
            block.getComponent('block').setLabel(this.level);
            this.blocks[this.location] = block;
            var move = cc.moveTo(MOVE_DURATION, blockLocation[this.location]);
            block.runAction(move);
        } else if (number == 4) {
            //backward one step
            var _block = this.blocks[this.location];
            if (this.lock != 0) return;
            this.blocks[this.location] = null;
            if (this.level == 1) {
                this.location = this.location - 1;
                if (this.location == 4) this.isOut = 1;
                if (this.location == 0) this.location = 4;
            } else {
                this.location = this.location - 1;
                if (this.location == 0) this.location = 4;else if (this.location == 4) this.location = 12;
            }
            _block.getComponent('block').setLabel(this.level);
            this.blocks[this.location] = _block;
            var _move = cc.moveTo(MOVE_DURATION, blockLocation[this.location]);
            _block.runAction(_move);
        } else if (number == 5) {
            //forward two steps
            var _block2 = this.blocks[this.location];
            if (this.lock != 0) return;
            this.blocks[this.location] = null;
            if (this.level == 1) {
                if (this.isOut == 1) {
                    this.location = (this.location + 2) % 4;
                    if (this.location == 0) this.location = 4;
                } else {
                    if (this.location == 11) {
                        this.location = 1;
                        this.isOut = 1;
                    } else if (this.location == 12) {
                        this.location = 2;
                        this.isOut = 1;
                    }
                }
            } else {
                this.location += 2;
                if (this.location == 5 || this.location == 6) this.isOut = 0;else if (this.location == 13) this.location = 5;else if (this.location == 14) this.location = 6;
            }
            _block2.getComponent('block').setLabel(this.level);
            this.blocks[this.location] = _block2;
            var _move2 = cc.moveTo(MOVE_DURATION, blockLocation[this.location]);
            _block2.runAction(_move2);
        } else if (number == 6) {
            //backward two steps
            var _block3 = this.blocks[this.location];
            if (this.lock != 0) return;
            this.blocks[this.location] = null;
            if (this.level == 1) {
                this.location = this.location - 2;
                if (this.location == 4 || this.location == 3) this.isOut = 1;else if (this.location == 0) this.location = 4;else if (this.location == -1) this.location = 3;
            } else {
                this.location = this.location - 2;
                if (this.location == 0) this.location = 4;else if (this.location == -1) this.location = 3;else if (this.location == 4) this.location = 12;else if (this.location == 3) this.location = 11;
            }
            _block3.getComponent('block').setLabel(this.level);
            this.blocks[this.location] = _block3;
            var _move3 = cc.moveTo(MOVE_DURATION, blockLocation[this.location]);
            _block3.runAction(_move3);
        } else if (number == 7) {
            //lock in
            if (this.lock == 0) {
                // let block = this.blocks[this.location];
                // block.destroy();
                this.blocks[this.location].getComponent('block').setLabel(0);
                //this.blocks[this.location] = null;
                if (this.location == 1 || this.location == 6 || this.location == 7) {
                    this.locks[1].getComponent('lock').setLabel(this.level);
                    this.lock = 1;
                } else if (this.location == 2 || this.location == 8 || this.location == 9) {
                    this.locks[2].getComponent('lock').setLabel(this.level);
                    this.lock = 2;
                } else if (this.location == 3 || this.location == 10 || this.location == 11) {
                    this.locks[3].getComponent('lock').setLabel(this.level);
                    this.lock = 3;
                } else if (this.location == 4 || this.location == 12 || this.location == 5) {
                    this.locks[4].getComponent('lock').setLabel(this.level);
                    this.lock = 4;
                }
            } else {
                this.toMove(5);
                this.step--;
            }
        } else if (number == 8) {
            //lock out
            if (this.lock != 0) {
                this.blocks[this.location].getComponent('block').setLabel(this.level);
                this.locks[this.lock].getComponent('lock').setLabel(0);
                this.lock = 0;
            } else {
                this.toMove(6);
                this.step--;
            }
        }
        this.isEnd(this.location);
    },
    isEnd: function isEnd(number) {
        if (number == 12) {
            cc.director.loadScene("over");
        }
    }
}
// update (dt) {},
);

cc._RF.pop();