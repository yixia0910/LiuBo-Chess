"use strict";
cc._RF.push(module, 'de4f8GTbdRKTrS+AoZJgP7X', 'block');
// scripts/block.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        Label: cc.Label
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {},
    setLabel: function setLabel(number) {
        if (number == 0) {
            this.Label.string = '';
            this.node.active = false;
            this.Label.node.active = false;
        } else if (number == 1) {
            this.node.active = true;
            this.Label.node.active = true;
            this.Label.string = '散';
        } else if (number == 2) {
            this.node.active = true;
            this.Label.node.active = true;
            this.Label.string = '枭';
        }
    }
}
// update (dt) {},
);

cc._RF.pop();