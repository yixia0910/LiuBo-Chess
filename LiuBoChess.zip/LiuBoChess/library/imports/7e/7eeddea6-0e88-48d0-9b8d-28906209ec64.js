"use strict";
cc._RF.push(module, '7eedd6mDohI0JuNKJBiCexk', 'click2');
// scripts/click2.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {},


    toOver: function toOver() {
        cc.director.loadScene("over");
    }
    // update (dt) {},
});

cc._RF.pop();