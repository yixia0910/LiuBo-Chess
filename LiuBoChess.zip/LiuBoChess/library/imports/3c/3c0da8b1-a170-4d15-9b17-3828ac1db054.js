"use strict";
cc._RF.push(module, '3c0daixoXBNFZsXOCisHbBU', 'click7');
// scripts/click7.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {},


    toCaidan: function toCaidan() {
        cc.director.loadScene("caidan");
    }
});

cc._RF.pop();